using System;
using HarmonyLib;

namespace CSharpClassLibraryTemplate.Patcher;


public static class Patcher
{
    private static Harmony patcher_;

    public static void Init()
    {
        if (patcher_ != null)
            return;
        
        patcher_ = new Harmony("modname.patcher");
        Debug.LogWarning("Patcher initialized.");
    }

    public static void TryPatch(Type type)
    {
        try
        {
            patcher_.PatchAll(type);
            Debug.LogWarning("Patch applied for " + type.Name);
        }
        catch (Exception ex)
        {
            Debug.LogError("Unable to apply patches for " + type.Name + ", error: " + ex.Message);
        }
    }
}