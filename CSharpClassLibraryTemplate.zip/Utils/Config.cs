using System.Diagnostics;
using System.IO;

namespace CSharpClassLibraryTemplate.Utils;

public class Config
{
    // How to use: 
    // Add any fields you want to store and load here.
    // call on Config.Instance to access them.
    // Example: public bool Enabled { get; set; } = true;
    // this will set a default value for something but allows it to be changed.
    
    public static Config Instance { get; private set; }
    private static readonly string ConfigPath = Path.Combine(Directory.GetParent(Application.dataPath)?.FullName ?? string.Empty, "SomeFolderName", "SomeFolderName", "modname.json");
    
    static Config()
    {
        Instance = new Config();
    }

    public void TryLoadConfig()
    {
        if (!File.Exists(ConfigPath))
        {
            Instance = new Config();
            Instance.Save();
            Debug.LogError("Config file not found, creating new one.");
        }
        else
        {
            Instance = File.ReadAllText(ConfigPath).FromJson<Config>();
            Debug.LogWarning("Config file loaded.");
        }
    }

    public void Save()
    {
        File.WriteAllText(ConfigPath, this.ToJson());
        Debug.LogWarning("Config file saved.");
    }
}