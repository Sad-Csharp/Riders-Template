using System;
using System.Diagnostics;
using System.Linq;
using System.Reflection;

namespace CSharpClassLibraryTemplate.Utils;

public static class SkinHelper
{
    public static GUISkin UniversalSkin;

    public static void TryLoadSkin()
    {
        try
        {
            var bundleData = LoadSkinFromMemory("SkinNameHere");
            var asset = AssetBundle.LoadFromMemory(bundleData);
            UniversalSkin = asset.LoadAsset<GUISkin>("SkinNameHere");
        }
        catch (Exception ex)
        {
            Debug.LogError("Unable to load skin, error: " + ex.Message);
        }
    }

    private static Byte[] LoadSkinFromMemory(string resourceName)
    {
        var assembly = Assembly.GetExecutingAssembly();
        using var stream = assembly.GetManifestResourceStream(assembly.GetManifestResourceNames().FirstOrDefault(x => x.EndsWith(resourceName)));

        if (stream == null) return null;

        var data = new byte[stream.Length];
        _ = stream.Read(data, 0, data.Length);
        return data;
    }
    
    public static Rect CenterWindow(Rect windowRect)
    {
        windowRect.x = (Screen.width - windowRect.width) / 2;
        windowRect.y = (Screen.height - windowRect.height) / 2;
        return windowRect;
    }
}