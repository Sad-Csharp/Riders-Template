namespace CSharpClassLibraryTemplate.Utils;

public static class UiHelper
{
    // TODO: Add UI helpers maybe?
    // guilayout labels with bold text, colored text, etc
    // using box styles both vertical and horizontal
    // slider with incrementing values
    // preset up grid selection maybe?
}