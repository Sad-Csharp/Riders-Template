﻿using BepInEx;
using CSharpClassLibraryTemplate.Utils;

namespace CSharpClassLibraryTemplate;

[BepInPlugin("com.Modname.mod", "Modname", "1.0.0")]
public class Main : BaseUnityPlugin
{

  #region Window

  Rect windowRect = new Rect(0, 0, 200, 200);
  private bool showWindow;

  #endregion
  
  private void Start()
  {
    Skin.TryLoadSkin();
    windowRect = Skin.CenterWindow(windowRect);
    Patcher.Init();
  }

  private void Update()
  {
      if (Input.GetKeyDown(KeyCode.None))
      {
          showWindow = !showWindow;
      }
  }

  private void OnGUI()
  {
      if (!showWindow) 
          return;
      
      if (Skin.UniversalSkin != null)
          GUI.skin = Skin.UniversalSkin;
      
      windowRect = GUILayout.Window(GetHashCode(), windowRect, DrawUI, "My Window");
  }
  
  private void DrawUI(int windowID)
  {
      GUI.DragWindow();
  }
}