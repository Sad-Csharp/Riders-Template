﻿using BepInEx;

namespace CSharpClassLibraryTemplate
{
  [BepInPlugin("com.Modname.mod", "Modname", "1.0.0")]
  public class Main : BaseUnityPlugin
  {
    private void Start()
    {
      
    }

    private void Update()
    {
      
    }

    private void OnGUI()
    {
      
    }
  }
}