using System;
using HarmonyLib;

namespace CSharpClassLibraryTemplate.Patcher;


public static class Patch
{
    private static Harmony patcher_;

    public static void Init()
    {
        if (patcher_ != null)
            return;
        
        patcher_ = new Harmony("modname.patcher");
    }

    public static void TryPatch(Type type)
    {
        try
        {
            patcher_.PatchAll(type);
        }
        catch (Exception ex)
        {
            // Debug.LogError("Unable to apply patches for " + type.Name + ", error: " + ex.Message);
        }
    }
}